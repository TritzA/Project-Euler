package euler;

import java.util.ArrayList;

public class ProblemeNo004PlusGrandPalindromeProduit2Nb3Chff {

	public static void main(String[] args) {

		ArrayList<Integer> tabPalin = new ArrayList<Integer>();
		for (long nbI = 998001; nbI >= 100000; nbI--) {
			String nbS = "" + nbI;
			// si nbI peut se pr�sent� comme le produit de deux nombres � trois
			// chiffre
			// alors
			if ((nbS.charAt(0) == nbS.charAt(5)) && (nbS.charAt(1) == nbS.charAt(4))
					&& (nbS.charAt(2) == nbS.charAt(3))) {
				// tabPalin.add((int) nbI);
				for (int j = 999; j >= 100; j--) {
					for (int k = 999; k >= 100; k--) {
						if (j * k == nbI) {
							tabPalin.add((int) nbI);
						}

					}
				}
			}

		}
		System.out.println(tabPalin.get(0));
	}
}
// 906609