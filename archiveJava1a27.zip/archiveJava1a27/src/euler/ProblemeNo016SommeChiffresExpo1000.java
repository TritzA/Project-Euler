package euler;

import java.math.BigInteger;

public class ProblemeNo016SommeChiffresExpo1000 {

	public static void main(String[] args) {

		BigInteger deux = BigInteger.ONE;
		BigInteger resultat = BigInteger.ONE;
		resultat = resultat.add(deux);
		// System.out.println(resultat);//2

		resultat = resultat.pow(1000);

		// System.out.println(resultat);

		String rep = resultat.toString();
		// System.out.println(rep);

		int nb = 0;
		for (int k = 0; k < rep.length(); k++) {
			nb += Integer.parseInt(rep.charAt(k) + "");
		}
		System.out.println(nb);

	}
}
// 1366