package euler;

public class ProblemeNo012DiviseursNbTriangulaire {

	public static void main(String[] args) {

		int nbDiviseurs = 0;
		long nbTri = 0;
		long incre = 1;
		while (nbDiviseurs <= 500) {
			nbTri = nbTri + incre;
			incre = incre + 1;
			nbDiviseurs = 0;
			for (int mod = 1; mod <= nbTri; mod++) {
				if (nbTri % mod == 0) {
					nbDiviseurs++;
				}
			}
			if (nbDiviseurs >= 200) {
				System.out.println(nbDiviseurs);
			}
			if (nbDiviseurs >= 500) {
				//System.out.println(nbTri + "!!!");
			}
		}
	}
}
// 76576500