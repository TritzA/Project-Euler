package euler;

public class Nombre {

	/*public static int[] facteurs(int nb) {

	}
	
	public static long[] facteurs(long nb) {

	}

	public static int[] facteursPremiers(int nb) {

	}
	
	public static long[] facteursPremiers(long nb) {

	}*/

	public static boolean estDeficient(int nb) {
		int somme = 0;

		for (int k = 1; k < nb; k++) {

			if (nb % k == 0) {
				somme += k;

			}
		}

		if (somme < nb) {
			return true;
		} else {
			return false;
		}
	}

	public static boolean estDeficient(long nb) {
		long somme = 0;

		for (long k = 1; k < nb; k++) {

			if (nb % k == 0) {
				somme += k;

			}
		}

		if (somme < nb) {
			return true;
		} else {
			return false;
		}
	}
	
	public static boolean estPropre(int nb) {

		int somme = 0;

		for (int k = 1; k < nb; k++) {

			if (nb % k == 0) {
				somme += k;

			}
		}

		if (somme == nb) {
			return true;
		} else {
			return false;
		}
	}
	
	public static boolean estPropre(long nb) {

		long somme = 0;

		for (long k = 1; k < nb; k++) {

			if (nb % k == 0) {
				somme += k;

			}
		}

		if (somme == nb) {
			return true;
		} else {
			return false;
		}
	}

	public static boolean estAbondans(int nb) {
		int somme = 0;

		for (int k = 1; k < nb; k++) {

			if (nb % k == 0) {
				somme += k;

			}
		}

		if (somme > nb) {
			return true;
		} else {
			return false;
		}
	}
	
	public static boolean estAbondans(long nb) {
		long somme = 0;

		for (long k = 1; k < nb; k++) {

			if (nb % k == 0) {
				somme += k;

			}
		}

		if (somme > nb) {
			return true;
		} else {
			return false;
		}
	}

	public static boolean estPremier(int nb) {

		boolean premier = true;

		for (int i = 2; i <= nb / 2; i++) {

			if (nb % i == 0) {
				premier = false;
				break;
			}
		}

		if (premier && nb > 0) {
			return true;
		} else {
			return false;
		}

	}
	
	public static boolean estPremier(long nb) {

		boolean premier = true;

		for (long i = 2; i <= nb / 2; i++) {

			if (nb % i == 0) {
				premier = false;
				break;
			}
		}

		if (premier && nb > 0) {
			return true;
		} else {
			return false;
		}

	}
	
	public static boolean estPremier(double nb) {

		boolean premier = true;

		for (int i = 2; i <= nb / 2; i++) {

			if (nb % i == 0) {
				premier = false;
				break;
			}
		}

		if (premier && nb > 0) {
			return true;
		} else {
			return false;
		}

	}

	public static int nbChiffres(int nb) {
		String nbS = Integer.toString(nb);
		return nbS.length();
	}
	
	public static int nbChiffres(long nb) {
		String nbS = Long.toString(nb);
		return nbS.length();
	}
	
	public static long Fibonacci(int n) {
	    long i = 0;
	    long j = 1;
	    long temp;
	    for (int k = 0; k < n; k++) {
	        temp = i + j;
	        i = j;
	        j = temp;
	    }
	    return i;
	}
	
	public static long Fibonacci(long n) {
	    long i = 0;
	    long j = 1;
	    long temp;
	    for (long k = 0; k < n; k++) {
	        temp = i + j;
	        i = j;
	        j = temp;
	    }
	    return i;
	}

}
