package euler;

import java.math.BigInteger;

public class ProblemeNo025RangNb1000ChiffresDansSuiteFibonacci {

	public static void main(String[] args) {

		BigInteger i = BigInteger.ZERO;
		BigInteger j = BigInteger.ONE;
		BigInteger temp;
		int k = 0;
		int compt = 0;
		while (k < 1000) {
			compt++;
			temp = i.add(j);
			i = j;
			j = temp;
			String rep = i.toString();
			//System.out.println(k);
			k = rep.length();
		}

		String rep = i.toString();
		k = rep.length();
		System.out.println(compt);

	}

}
// 4782