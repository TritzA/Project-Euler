package euler;

public class ProblemeNo019PremierDimancheMoisVingteSciecle {

	public static void main(String[] args) {
		int comptDim = 0;

		int[] nbJdansM = { 0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };// attention � f�vrier
		String[] sem = { "lundi", "mardi", "mercredi", "jeudi", "vendredi", "samedi", "dimanche" };

		Object[][][] mat = new Object[2001][13][32];// annee mois jourNb (jourStr)

		int comptJ = 0;
		for (int a = 1900; a <= 2000; a++) {
			for (int m = 1; m <= 12; m++) {
				int nbJdM = nbJdansM[m];
				if (m == 2 && ((a % 4 == 0 && a % 100 != 0) || a % 400 == 0)) {
					nbJdM = 29;
				}
				for (int j = 1; j <= nbJdM; j++) {
					mat[a][m][j] = sem[comptJ];
					// System.out.println("add "+a+" "+m+" "+j+" "+comptJ);
					comptJ = (comptJ + 1) % 7;
				}
			}
		}

		for (int a = 1901; a <= 2000; a++) {
			for (int m = 1; m <= 12; m++) {
				int nbJdM = nbJdansM[m];
				if (m == 2 && ((a % 4 == 0 && a % 100 != 0) || a % 400 == 0)) {
					nbJdM = 29;
				}
				for (int j = 1; j <= nbJdM; j++) {

					if (j == 1 && (mat[a][m][j]).equals(sem[6])) {
						// System.out.println("Le "+ j +" du "+ m +"e mois "+ a +" etait un "+
						// mat[a][m][j]);
						comptDim++;
					}
				}
			}
		}
		System.out.println(comptDim);
	}
	// Le 28 du 2e mois 1900 etait un mercredi Le 1 du 3e mois 1900 etait un
	// vendredi

}
// 171