package euler;

public class ProblemeNo009TripletsPytagoricien {

	public static void main(String[] args) {
		double a;
		double b;
		double c;
		long rep = 0;

		for (a = 1; a <= 1000; a++) {
			// System.out.println(a);
			for (b = 1; b <= 1000; b++) {
				c = Math.sqrt(((Math.pow(a, 2)) + (Math.pow(b, 2))));
				if (a + b + c == 1000) {
					rep = (long) (a * b * c);
					// System.out.println(rep);
				}
			}
		}
		System.out.println(rep);
	}
}
// 31875000