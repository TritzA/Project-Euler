package euler;

/*
 * Tritz
 * Yo73jc25
 * Recovery Key:1387552-KbuNS76OaRZHNMADe0IxmnPCK9iZtaUG302b7HV0
 * Fri, 21 Jun 2019, 03:07.13
 */

public class ProblemeNo001Multi3Et5 {

	public static void main(String[] args) {

		int x, somme;
		somme = 0;

		for (x = 1; x < 1000; ++x) {
			if (x % 3 == 0 || x % 5 == 0) {
				somme = somme + x;
			}
		}
		System.out.println(somme);
	}
}
// 233168