package euler;

public class ProblemeNo005Modulo1a20 {

	public static void main(String[] args) {

		int nb = 20;
		while (!(nb % 20 == 0 && nb % 19 == 0 && nb % 18 == 0 && nb % 17 == 0 && nb % 16 == 0 && nb % 15 == 0
				&& nb % 14 == 0 && nb % 13 == 0 && nb % 12 == 0 && nb % 11 == 0 && nb % 10 == 0 && nb % 10 == 0
				&& nb % 9 == 0 && nb % 8 == 0 && nb % 7 == 0 && nb % 6 == 0 && nb % 5 == 0 && nb % 4 == 0 && nb % 3 == 0
				&& nb % 2 == 0 && nb % 1 == 0)) {
			nb++;
		}
		System.out.println(nb);
	}
}
// 232792560