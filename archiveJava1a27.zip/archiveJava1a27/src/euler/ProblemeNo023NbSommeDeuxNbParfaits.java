package euler;

public class ProblemeNo023NbSommeDeuxNbParfaits {

	public static void main(String[] args) {
		int[] vec = new int[6965];
		vec = listeNbAbon();

		int s1 = 0, s2 = 0;
		for (int i = 1; i <= 28123; i++) {
			// System.out.println(i);
			for (int j = 0; j < 6965; j++) {
				for (int k = 6964; k >= 0; k--) {
					if (i == vec[j] + vec[k]) {
						j = 6965;
						k = -1;
						s1 += i;
					}
				}
			}
		}
		s2 = (28123 * (28123 + 1)) / 2;
		// System.out.println(s2);//395465626
		// System.out.println(s1);
		System.out.println(s2 - s1);
	}

	private static int estParfait(int nb) {

		int pro;

		int somme = 0;

		for (int k = 1; k < nb; k++) {

			if (nb % k == 0) {
				somme += k;
				// System.out.println(k);
			}
		}

		if (somme == nb) {
			pro = 0;
		} else if (somme < nb) {
			pro = -1;
		} else {
			pro = 1;
		}

		return pro;

	}

	private static int[] listeNbAbon() {

		int[] vec = new int[6965];

		int compt = 0;

		for (int k = 1; k <= 28123; k++) {

			if (estParfait(k) == 1) {
				vec[compt] = k;
				// System.out.println(k);
				compt++;
			}

		}
		return vec;
	}

}
// 4179871