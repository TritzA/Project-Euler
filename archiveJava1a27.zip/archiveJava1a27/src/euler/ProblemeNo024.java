package euler;

public class ProblemeNo024 {

	public static void main(String[] args) {
		
		@SuppressWarnings("unused")
		int compt = 1;
		
		for(int a = 0; a<3; a++) {
			for(int b = 1; b<3; b++) {
				for(int c = 2; c<3; c++) {
					/*for(int d = 3; d<10; d++) {
						for(int e = 4; e<10; e++) {
							for(int f = 5; f<10; f++) {
								for(int g = 6; g<10; g++) {
									for(int h = 7; h<10; h++) {
										for(int i = 8; i<10; i++) {
											for(int j = 9; j<10; j++) {*/
												System.out.println(a+" "+b+" "+c);
												compt++;
											}
										}
									}
								/*}
							}
						}
					}
				}
			}
			
		}*/
	}

}
