package euler;

import java.math.BigInteger;

public class ProblemeNo020Factoriel100 {

	public static void main(String[] args) {

		BigInteger resultat = facto(BigInteger.TEN.multiply(BigInteger.TEN));

		String rep = resultat.toString();
		// System.out.println(rep);

		int nb = 0;
		for (int k = 0; k < rep.length(); k++) {
			nb += Integer.parseInt(rep.charAt(k) + "");
		}
		System.out.println(nb);

	}

	private static BigInteger facto(BigInteger nb) {
		if (nb.equals(BigInteger.ZERO)) {
			return BigInteger.ONE;
		} else {
			return nb.multiply(facto(nb.subtract(BigInteger.ONE)));
		}
	}
}
// 648