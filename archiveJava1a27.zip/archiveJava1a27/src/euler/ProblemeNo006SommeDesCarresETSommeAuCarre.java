package euler;

import javax.swing.JOptionPane;

public class ProblemeNo006SommeDesCarresETSommeAuCarre {

	public static void main(String[] args) {

		int n = Integer.parseInt(JOptionPane.showInputDialog(
				"Ce programme calcul la somme des carr�s de n termes et les carr� de la somme de n termes, entrer n.",
				"100"));
		int sommeCarre = 0;
		for (int i = 1; i <= n; i++) {
			sommeCarre = sommeCarre + (i * i);// Math.pow(i,2);
		}
		// System.out.println(sommeCarre);

		int carreSomme = (int) Math.pow(((n / 2) * (n + 1)), 2);// 2,( (10/2)*(10+1)));
		// System.out.println(carreSomme);

		int rep = carreSomme - sommeCarre;
		System.out.println(rep);

	}
}
// 25164150