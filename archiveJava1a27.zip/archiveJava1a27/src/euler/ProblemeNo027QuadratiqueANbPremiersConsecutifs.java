package euler;

public class ProblemeNo027QuadratiqueANbPremiersConsecutifs {

	public static void main(String[] args) {
		
		int max = 0;
		int tempo;
		
		int rA = 1;
		int rB = 1;
		
		System.out.println(score(-1,41));
		
		for(int a = -1000; a<1000; a++) {
			System.out.println(a);
			for(int b = -1000; b<1000; b++) {
				tempo = score(a,b);
				if(tempo > max) {
					max=tempo;
					rA=a;
					rB=b;
				}
			}
		}
		//System.out.println(rA+" "+rB);
		System.out.println(rA*rB);
	}
	
	private static int score (int a, int b) {
		int nb;
		int n = 0;
		do {
			nb = quadra(n, a, b);
			n++;
		}while(Nombre.estPremier(nb));
		return n-2;
	}
	private static int quadra(int x, int a, int b) {
		return x*x+a*x+b;
	}

}
//-59231