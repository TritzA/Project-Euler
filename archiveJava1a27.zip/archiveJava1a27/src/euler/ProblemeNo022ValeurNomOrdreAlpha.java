package euler;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;

public class ProblemeNo022ValeurNomOrdreAlpha {

	public static void main(String[] args) throws IOException, InterruptedException {

		String chaine = lire("nomAlpha.txt");

		chaine = chaine.replaceAll("\"", "");
		chaine +=",";
		
		//System.out.println(chaine);
		//System.out.println(compterOccurrences(chaine, ','));
		int nbE = compterOccurrences(chaine, ',');
		String[] nom = new String[nbE];

		for (int k = 0; k < nbE; k++) {
			String ajout = "";
			try {

					ajout = chaine.substring(0, chaine.indexOf(","));
					nom[k] = ajout;
					chaine = chaine.substring(chaine.indexOf(",")+1);
					Thread.sleep(3);

			} catch (StringIndexOutOfBoundsException e) {
				//System.out.println(e+" "+k);
			}
		}

		Arrays.sort(nom);
		for (int i = 0; i < nom.length; i++) {
			//System.out.print(nom[i]+",");
		}
		
		long somme = 0;
		final String ALPHA = "*ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		for (int i = 0; i < nom.length; i++) {
			int points = 0;
			int multipli = i + 1;
			int resu = 0;

			for (int k = 0; k < nom[i].length(); k++) {
				points+=  ALPHA.indexOf(nom[i].charAt(k));
			}

			resu = points * multipli;
			somme += resu;
			//System.out.println(nom[i] + " " + resu);
			Thread.sleep(3);
		}
		System.out.println(somme);
		
	}
    
	
	private static String lire(String nomF) throws IOException {
		FileReader nomFichier;
		BufferedReader fluxEntree;

		nomFichier = new FileReader(nomF);
		fluxEntree = new BufferedReader(nomFichier);

		String nom;

		nom = fluxEntree.readLine();

		fluxEntree.close();
		return nom;
	}

	private static int compterOccurrences(String maChaine, char recherche) {
		int nb = 0;
		for (int i = 0; i < maChaine.length(); i++) {
			if (maChaine.charAt(i) == recherche)
				nb++;
		}
		return nb;
	}

}
// 871198282