package euler;

public class ProblemeNo026 {

	public static void main(String[] args) {
		double divi;
		String diviS;
		for (double k = 1; k < 1001; k++) {
			if (Nombre.estPremier(k) == true || k / 3 == 0) {
				divi = 1000000 / k;
				diviS = Double.toString(divi);
				System.out.println(diviS);
			}
		}

	}

}
