package euler;

public class ProblemeNo002SommeFibona {

	public static void main(String[] args) {

		int s1 = 1;
		int s2 = 2;
		int sTot = 2;

		while (s1 <= 4000000 || s2 <= 4000000) {
			s1 = s1 + s2;
			if (s1 % 2 == 0) {
				sTot = sTot + s1;
			}
			s2 = s1 + s2;
			if (s2 % 2 == 0) {
				sTot += s2;
			}
		}
		System.out.println(sTot);
	}

}
// 4613732