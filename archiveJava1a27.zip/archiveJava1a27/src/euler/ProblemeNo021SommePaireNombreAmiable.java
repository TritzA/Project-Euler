package euler;

public class ProblemeNo021SommePaireNombreAmiable {

	public static void main(String[] args) {
		int somme = 0;
		for (int k = 1; k < 10000; k++) {
			int autre = d(k);
			if (d(autre) == k && k != autre) {
				somme += k;
			}
		}
		System.out.println(somme);
	}

	private static int d(int n) {
		int somme = 1;
		for (int k = 2; k < ((n + 2) / 2); k++) {
			if (n % k == 0) {
				somme += k;
			}
		}
		return somme;
	}

}
// 31626