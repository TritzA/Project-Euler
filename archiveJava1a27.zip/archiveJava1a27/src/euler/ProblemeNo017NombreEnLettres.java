package euler;

public class ProblemeNo017NombreEnLettres {

	public static void main(String[] args) {

		String rep = "";
		String tempo = "";

		for (int k = 1; k <= 999; k++) {
			String mot = String.valueOf(k);
			tempo = ((centaine(mot)).replaceAll(" ", "")).replaceAll("-", "");
			rep += tempo;
			// System.out.println(k + " " + centaine(mot));

		}
		rep += (("one thousand").replaceAll(" ", ""));
		// System.out.println("one thousand");

		// System.out.println(rep);
		System.out.println(rep.length());

	}

	private static String unite(String mot) {
		if (mot.length() == 1) {
			mot = "00" + mot;
		} else if (mot.length() == 2) {
			mot = "0" + mot;
		}
		// int d = Integer.parseInt(mot.substring(mot.length() - 2, mot.length() - 1));
		// String dS = mot.substring(mot.length() - 2, mot.length() - 1);
		int u = Integer.parseInt(mot.substring(mot.length() - 1, mot.length()));
		// String uS = mot.substring(mot.length() - 1, mot.length());

		switch (u) {
		case 0:
			return "";
		case 1:
			return "one";
		case 2:
			return "two";
		case 3:
			return "three";
		case 4:
			return "four";
		case 5:
			return "five";
		case 6:
			return "six";
		case 7:
			return "seven";
		case 8:
			return "eight";
		case 9:
			return "nine";
		default:
			return "erreur";
		}
	}

	private static String dizaine(String mot) {
		if (mot.length() == 1) {
			mot = "00" + mot;
		} else if (mot.length() == 2) {
			mot = "0" + mot;
		}

		int d = Integer.parseInt(mot.substring(mot.length() - 2, mot.length() - 1));
		// String dS = mot.substring(mot.length() - 2, mot.length() - 1);
		int u = Integer.parseInt(mot.substring(mot.length() - 1, mot.length()));
		String uS = mot.substring(mot.length() - 1, mot.length());

		switch (d) {
		case 0:
			return "" + unite(uS);
		// break;
		case 1:
			if (u == 0) {
				return "ten";
			} else if (u == 1) {
				return "eleven";
			} else if (u == 2) {
				return "twelve";
			} else if (u == 3) {
				return "thirteen ";
			} else if (u == 4) {
				return "fourteen";
			} else if (u == 5) {
				return "fifteen";
			} else if (u == 6) {
				return "sixteen";
			} else if (u == 7) {
				return "seventeen";
			} else if (u == 8) {
				return "eighteen";
			} else if (u == 9) {
				return "nineteen";
			} else {
				return "ten" + unite(uS);
			}

		case 2:
			if (u == 0) {
				return "twenty";
			} else {
				return "twenty-" + unite(uS);
			}

		case 3:
			if (u == 0) {
				return "thirty";
			} else {
				return "thirty-" + unite(uS);
			}
		case 4:
			if (u == 0) {
				return "forty";
			} else {
				return "forty-" + unite(uS);
			}
		case 5:
			if (u == 0) {
				return "fifty";
			} else {
				return "fifty-" + unite(uS);
			}
		case 6:
			if (u == 0) {
				return "sixty";
			} else {
				return "sixty-" + unite(uS);
			}
		case 7:
			if (u == 0) {
				return "seventy";
			} else {
				return "seventy-" + unite(uS);
			}
		case 8:
			if (u == 0) {
				return "eighty";
			} else {
				return "eighty-" + unite(uS);
			}
		case 9:
			if (u == 0) {
				return "ninety";
			} else {
				return "ninety-" + unite(uS);
			}
		default:
			return "erreur";
		}

	}

	private static String centaine(String mot) {
		if (mot.length() == 1) {
			mot = "00" + mot;
		} else if (mot.length() == 2) {
			mot = "0" + mot;
		}

		int d = Integer.parseInt(mot.substring(mot.length() - 2, mot.length() - 1));
		// String dS = mot.substring(mot.length() - 2, mot.length() - 1);
		int u = Integer.parseInt(mot.substring(mot.length() - 1, mot.length()));
		// String uS = mot.substring(mot.length() - 1, mot.length());
		int c = Integer.parseInt(mot.substring(mot.length() - 3, mot.length() - 2));
		// String uC = mot.substring(mot.length() - 3, mot.length() - 2);

		switch (c) {
		case 0:
			return "" + dizaine(mot);
		case 1:
			if (u == 0 && d == 0) {
				return "one hundred" + dizaine(mot);
			} else {
				return "one hundred and " + dizaine(mot);
			}
		case 2:
			if (u == 0 && d == 0) {
				return "two hundred" + dizaine(mot);
			} else {
				return "two hundred and " + dizaine(mot);
			}
		case 3:
			if (u == 0 && d == 0) {
				return "three hundred" + dizaine(mot);
			} else {
				return "three hundred and " + dizaine(mot);
			}
		case 4:
			if (u == 0 && d == 0) {
				return "four hundred" + dizaine(mot);
			} else {
				return "four hundred and " + dizaine(mot);
			}
		case 5:
			if (u == 0 && d == 0) {
				return "five hundred" + dizaine(mot);
			} else {
				return "five hundred and " + dizaine(mot);
			}
		case 6:
			if (u == 0 && d == 0) {
				return "six hundred" + dizaine(mot);
			} else {
				return "six hundred and " + dizaine(mot);
			}
		case 7:
			if (u == 0 && d == 0) {
				return "seven hundred" + dizaine(mot);
			} else {
				return "seven hundred and " + dizaine(mot);
			}
		case 8:
			if (u == 0 && d == 0) {
				return "eight hundred" + dizaine(mot);
			} else {
				return "eight hundred and " + dizaine(mot);
			}
		case 9:
			if (u == 0 && d == 0) {
				return "nine hundred" + dizaine(mot);
			} else {
				return "nine hundred and " + dizaine(mot);
			}
		default:
			return "erreur";
		}
	}

}
// 21124