package euler;

import java.util.ArrayList;

public class ProblemeNo003PlusGrandFacteurPremier {

	public static void main(String[] args) {

		long nb;
		long mod = 2l;
		ArrayList<Integer> facteurs = new ArrayList<Integer>();

		nb = Long.parseLong("600851475143");
		while (nb > 1) {
			while (nb % mod == 0) {
				// System.out.println(mod);
				facteurs.add((int) mod);
				nb = nb / mod;
			}
			mod = mod + 1;
		}
		System.out.println(facteurs.get(facteurs.size() - 1));
	}
}
// 6857