package projectEuler;

import java.util.ArrayList;

public class ProblemeNo014ConjectureCollatz {
	

	public static void main(String[] args) {
		
		long startTime = System.nanoTime();
		ArrayList<Integer> tabSeq = new ArrayList<Integer>();
		int reponse=0;
		int maxSeq=1;
		for (int nb = 1; nb < 1000000; nb++) {
			//System.out.println(nb);
			int longSeq = 1;
			long nbTra = nb;
			while (nbTra != 1) {
				//System.out.println(nbTra);
				if (nbTra % 2 == 0) {
					nbTra = nbTra / 2;
					longSeq++;
				} else {
					nbTra = 3 * nbTra + 1;
					longSeq++;
				}
			}
			if(longSeq>maxSeq) {
				reponse=nb;
				maxSeq=longSeq;
			}

			tabSeq.add(longSeq);
		}

		//int i = Collections.max(tabSeq);
		//System.out.println("Longeur de la s�quence : " + i);
		System.out.println(reponse);
		long endTime = System.nanoTime();
		System.out.println("Le programme trouve la r�ponse en : " + (endTime - startTime)/1000000000. + " secondes.");
	}

}
// 837799
// Le programme trouve la r�ponse en : 0.583287042 secondes.