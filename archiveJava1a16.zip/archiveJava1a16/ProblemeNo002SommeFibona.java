package projectEuler;

public class ProblemeNo002SommeFibona {

	public static void main(String[] args) {

		int somme1 = 1;
		int somme2 = 2;
		int sommetot = 2;

		while (somme1 <= 4000000 || somme2 <= 4000000) {
			somme1 = somme1 + somme2;
			if (somme1 % 2 == 0) {
				sommetot = sommetot + somme1;
			}
			somme2 = somme1 + somme2;
			if (somme2 % 2 == 0) {
				sommetot = sommetot + somme2;
			}
		}
		System.out.println(sommetot);
	}

}
// 4613732