package projectEuler;

public class ProblemeNo016SommeChiffresExpo1000 {

	public static void main(String[] args) {

		// 2^1000

		// 2*2*2 ... *2, 1000 fois

		// a*2, c'est a+a
		int expo = 50;
		long[] somme = new long [1];
		somme[0] = 2;
		for (int k = 0; k < expo-1; k++) {
			for (int i = 0; i < 1; i++) {//le nombre plus le nombre, stock les retenue, applique a la fin (plusieurs fois) puis recommence encore 1950 fois
						somme[i]=(somme[i]*2);
			}
		}
		for(int a = 0; a < 1; a++) {
			System.out.print(somme[a]);
		}
	}
}
// 