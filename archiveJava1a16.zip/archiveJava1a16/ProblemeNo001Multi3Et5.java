package projectEuler;

public class ProblemeNo001Multi3Et5 {

	public static void main(String[] args) {

		int x, somme;
		somme = 0;

		for (x = 1; x < 1000; ++x) {
			if (x % 3 == 0 || x % 5 == 0) {
				somme = somme + x;
			}
		}
		System.out.println(somme);
	}
}
// 233168