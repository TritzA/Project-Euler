package projectEuler;

public class ProblemeNo007Le10001�meNbPremier {

	public static void main(String[] args) {

		int nb = 2;
		int nbPremier = 0;
		boolean premier;

		while (nbPremier < 10001) {

			premier = true;
			for (int x = 2; x < nb; x++) {
				if (nb % x == 0) {
					premier = false;
				}
			}
			if (premier == true) {
				nbPremier = nbPremier + 1;
			}
			// System.out.println(nbPremier);
			nb = nb + 1;
		}
		// System.out.println(nbPremier);
		System.out.println(nb - 1);
	}
}
// 104743