package projectEuler;

public class ProblemeNo010SommeNbPremierPlusPetit2M {

	public static void main(String[] args) {
		
		int nb = 4;
		long somme = (2 + 3);
		boolean premier;

		for (nb = 4; nb <=2000000; nb++) {
			premier = true;
			System.out.println(nb);
			for (int mod = 2; mod < nb; mod++) {
				if (nb % mod == 0) {
					premier = false;
					mod=nb;
					//System.out.println(premier);
				}
			}
			if (premier == true) {
				somme = somme + nb;
				//System.out.println(nb+"!!!!!");
			}
		}
		System.out.println(somme);
	}
}
// 142913828922