package projectEuler;


public class ProblemeNo015Diff�rentsCheminsTableau20x20 {

	public static void main(String[] args) {
		int aVerifier;
		long poss = 0;
		int pass = 21;
		for(int a = 0; a < 21; a++) {
			System.out.println("*"+pass);
			pass -=1;
			for(int b = 0; b < 20; b++) {
				for(int c = 0; c < 19; c++) {
					for(int d = 0; d < 18; d++) {
						for(int e = 0; e < 17; e++) {
							for(int f = 0; f < 16; f++) {
								for(int g = 0; g < 15; g++) {
									for(int h = 0; h < 14; h++) {
										for(int i = 0; i < 13; i++) {
											for(int j = 0; j < 12; j++) {
												for(int k = 0; k < 11; k++) {
													for(int l = 0; l < 10; l++) {
														for(int m = 0; m < 9; m++) {
															for(int n = 0; n < 8; n++) {
																for(int o = 0; o < 7; o++) {
																	for(int p = 0; p < 6; p++) {
																		for(int q = 0; q < 5; q++) {
																			for(int r = 0; r < 4; r++) {
																				for(int s = 0; s < 3; s++) {
																					for(int t = 0; t < 2; t++) {
																						for(int u = 0; u < 1; u++) {
																							poss++;
																						}	
																					}	
																				}	
																			}	
																		}	
																	}	
																}	
															}	
														}	
													}	
												}	
											}	
										}	
									}	
								}	
							}	
						}	
					}
				}
			}
		}
		System.out.println(poss);
	}
}
// 137846528820 